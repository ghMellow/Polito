/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "GLCD.h"
#include "../timer/timer.h"
#include <stdio.h>

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
#define HEIGTH 31
#define LENGTH 28
#define SCALE 7
#define PADD_X 20
#define PADD_Y 40

// beat 1/4 = 1.65/4 seconds
#define RIT_SEMIMINIMA 8
#define RIT_MINIMA 16
#define RIT_INTERA 32
#define UPTICKS 1

// Variabili globali
volatile int backgroundActive = 0;  // 1: musica di sottofondo attiva, 0: interrotta
volatile int playEatSound = 0;      // 1: riproduci suono "mangiare", 0: continua musica di sottofondo
// Variabili per tenere traccia dello stato delle note
static int currentNoteBackground = 0;
static int currentNoteEatSound = 0;
static int ticks = 0;
NOTE eat_song[1] = {
	//{0, 0x4C4B40},
	//{500, 0x1C4B40},
	{700, 0x1C4B40}
	//{1400, 0x4C4B40}
};

NOTE click = {1400, 0x0C4B40};

NOTE backgroundMusic[6] = {
	{e3, 0x989680},
	{f3, 0x4C4B40},
	{d3, 0x989680},
	{e3, 0x4C4B40},
	{c3, 0x989680},
	{d3, 0x4C4B40}
};


extern char board[HEIGTH][LENGTH];
extern int pacman_i; // y
extern int pacman_j; // x
extern int ghost_i; // y
extern int ghost_j; // x
extern int spawnP_i;
extern int spawnP_j;
extern int spawnG_i;
extern int spawnG_j;
extern int ghostSpeed;
int ghostSpeedSkip = 0;
extern int flag_ghostDead;

int point = 0;
char scoreString[200];
int lives = 3;
int endGamePoint = 2700;
extern int game_state;
volatile int frightenedMode = -1;
volatile int ghostAlive = 1;


void drawLives(){
	switch(lives){
		case 0:
			GUI_Text(0, 280, (uint8_t *) " Lives: x_x      ", White, Black);
			game_state = 3;
			break;
		case 1:
			GUI_Text(0, 280, (uint8_t *) " Lives: (<       ", White, Black);
			break;
		case 2:
			GUI_Text(0, 280, (uint8_t *) " Lives: (< (<    ", White, Black);
			break;
		case 3:
			GUI_Text(0, 280, (uint8_t *) " Lives: (< (< (< ", White, Black);
			break;
		default:
			break;
		}
}
void addLive() {
	if(lives != 3 && point != 0 && point % 1000 == 0) {
		lives += 1;
		drawLives();
	}
}

volatile int countPills = 0;
int countPowerPills = 0;
extern int flag_frightenedMode;
void addPoint(){
	if(board[pacman_i][pacman_j] == 2) {
		countPills++;
		point += 10;
		playEatSound = 1;
	} else if (board[pacman_i][pacman_j] == 3) {
		countPowerPills++;
		point += 50;
		
		frightenedMode = 7;
		//enable_timer(0);
		flag_frightenedMode = 1;
		playEatSound = 1;
	}
	addLive();
	
	if(countPills + countPowerPills >= 240){
		game_state = 2;
		drawMap();
	}
	
	/*if(point != 0) {
		playEatSound = 1;
	}*/
	
	sprintf(scoreString, "      %d  ", point);
	GUI_Text(120, 20, (uint8_t *)scoreString, White, Black);
}

void teleport(int portal){
	if(portal == 1){
		pacman_i = 14;
		pacman_j = 26;
		board[pacman_i][pacman_j] = 6;
	} else {
		pacman_i = 14;
		pacman_j = 1;
		board[pacman_i][pacman_j]	= 6;
	}
}


int firstGhostMove = 2;
int restoreValue, restoreI, restoreJ;
void drawRestore(){
	draw_null(restoreJ*SCALE, restoreI*SCALE, PADD_X, PADD_Y);
	board[restoreI][restoreJ] = restoreValue;
	switch(restoreValue) {
		case 0:
			draw_null(restoreJ*SCALE, restoreI*SCALE, PADD_X, PADD_Y);
			break;
		case 2:
			draw_point(restoreJ*SCALE, restoreI*SCALE, PADD_X, PADD_Y);
			break;
		case 3:
			draw_pills(restoreJ*SCALE, restoreI*SCALE, PADD_X, PADD_Y);
			break;
	}
}
void moveGhost(){
	if(ghostAlive == 0) {
		return;
	}
	if(firstGhostMove != 0){
		if(firstGhostMove == 2){
			firstGhostMove--;
			board[ghost_i][ghost_j] = 8;
			drawPoint(10);
			
			ghost_i--;
			board[ghost_i][ghost_j] = 7;
			drawPoint(7);
		} else {
			firstGhostMove--;
			board[ghost_i][ghost_j] = 8;
			drawPoint(7);
			
			ghost_i--;
			restoreValue = board[ghost_i][ghost_j];
			restoreI = ghost_i;
			restoreJ = ghost_j;
			board[ghost_i][ghost_j] = 7;
			drawPoint(7);
			ghostAlive = 1;
		}
		
		// up,left,down,right
	} else {
				
		if(frightenedMode == -1){
			if(ghost_i > pacman_i && (board[ghost_i-1][ghost_j] != 1 && board[ghost_i-1][ghost_j] != 8)) {
				drawRestore();
						
				ghost_i--;
				restoreValue = board[ghost_i][ghost_j];
				restoreI = ghost_i;
				restoreJ = ghost_j;
				board[ghost_i][ghost_j] = 7;
				drawPoint(7);
				
			} else if(ghost_j > pacman_j && (board[ghost_i][ghost_j-1] != 1 && board[ghost_i][ghost_j-1] != 8)) {
				drawRestore();
				
				ghost_j--;
				restoreValue = board[ghost_i][ghost_j];
				restoreI = ghost_i;
				restoreJ = ghost_j;
				board[ghost_i][ghost_j] = 7;
				drawPoint(7);		
			
			} else if(ghost_i < pacman_i && (board[ghost_i+1][ghost_j] != 1 && board[ghost_i+1][ghost_j] != 8)){
				drawRestore();
				
				ghost_i++;
				restoreValue = board[ghost_i][ghost_j];
				restoreI = ghost_i;
				restoreJ = ghost_j;
				board[ghost_i][ghost_j] = 7;
				drawPoint(7);		
			
			} else if(ghost_j <= pacman_j && (board[ghost_i][ghost_j+1] != 1 && board[ghost_i][ghost_j+1] != 8)) {
				drawRestore();
				
				ghost_j++;
				restoreValue = board[ghost_i][ghost_j];
				restoreI = ghost_i;
				restoreJ = ghost_j;
				board[ghost_i][ghost_j] = 7;
				drawPoint(7);		
			}
		} else {
			if(ghost_i < pacman_i && (board[ghost_i-1][ghost_j] != 1 && board[ghost_i-1][ghost_j] != 8)) {
				drawRestore();
						
				ghost_i--;
				restoreValue = board[ghost_i][ghost_j];
				restoreI = ghost_i;
				restoreJ = ghost_j;
				board[ghost_i][ghost_j] = 7;
				drawPoint(-7);
				
			} else if(ghost_j < pacman_j && (board[ghost_i][ghost_j-1] != 1 && board[ghost_i][ghost_j-1] != 8)) {
				drawRestore();
				
				ghost_j--;
				restoreValue = board[ghost_i][ghost_j];
				restoreI = ghost_i;
				restoreJ = ghost_j;
				board[ghost_i][ghost_j] = 7;
				drawPoint(-7);		
			
			} else if(ghost_i > pacman_i && (board[ghost_i+1][ghost_j] != 1 && board[ghost_i+1][ghost_j] != 8)){
				drawRestore();
				
				ghost_i++;
				restoreValue = board[ghost_i][ghost_j];
				restoreI = ghost_i;
				restoreJ = ghost_j;
				board[ghost_i][ghost_j] = 7;
				drawPoint(-7);		
			
			} else if(ghost_j >= pacman_j && (board[ghost_i][ghost_j+1] != 1 && board[ghost_i][ghost_j+1] != 8)) {
				drawRestore();
				
				ghost_j++;
				restoreValue = board[ghost_i][ghost_j];
				restoreI = ghost_i;
				restoreJ = ghost_j;
				board[ghost_i][ghost_j] = 7;
				drawPoint(-7);		
			}
		}
	
		
	}
}

void moveRight(){
    if(board[pacman_i][pacman_j + 1] == 5) {    
				board[pacman_i][pacman_j] = 0;
				drawPoint(6);
				
				teleport(0);
				drawPoint(6);
			
		} else if (board[pacman_i][pacman_j + 1] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
				drawPoint(6);
			
        pacman_j += 1;                           // Aggiorna la posizione del pacman
				addPoint();
        board[pacman_i][pacman_j] = 6;           // Imposta il pacman nella nuova posizione
				drawPoint(6);
    }
}

void moveLeft(){
    if(board[pacman_i][pacman_j - 1] == 4) {    
				board[pacman_i][pacman_j] = 0;
				drawPoint(6);
				teleport(1);
				drawPoint(6);
			
		} else if (board[pacman_i][pacman_j - 1] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
				drawPoint(6);
        pacman_j -= 1;                           // Aggiorna la posizione del pacman
				addPoint();
        board[pacman_i][pacman_j] = 6; 
				drawPoint(6);
		
		}
		
}

void moveDown(){
    if (board[pacman_i + 1][pacman_j] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
				drawPoint(6);
        pacman_i += 1;                           // Aggiorna la posizione del pacman
				addPoint();
        board[pacman_i][pacman_j] = 6;           // Imposta il pacman nella nuova posizione
				drawPoint(6);
    }
}

void moveUp(){
    if (board[pacman_i - 1][pacman_j] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
				drawPoint(6);
        pacman_i -= 1;                           // Aggiorna la posizione del pacman
				addPoint();
        board[pacman_i][pacman_j] = 6;           // Imposta il pacman nella nuova posizione
				drawPoint(6);
    }
}


volatile int bt=0;
static int position = 0;

void RIT_IRQHandler (void)
{					
	// Joystick UP
	if ((LPC_GPIO1->FIOPIN & (1 << 29)) == 0) {
		if (position != 1) { // Evita ripetizioni
			position = 1;
		}
	}

	// Joystick RIGHT
	if ((LPC_GPIO1->FIOPIN & (1 << 28)) == 0) {
		if (position != 2) {
			position = 2;
		}
	}

	// Joystick LEFT
	if ((LPC_GPIO1->FIOPIN & (1 << 27)) == 0) {
		if (position != 3) {
			position = 3;
		}
	}

	// Joystick DOWN
	if ((LPC_GPIO1->FIOPIN & (1 << 26)) == 0) {
		if (position != 4) {
			position = 4;
		}
	}

	// Joystick SELECT
	if ((LPC_GPIO1->FIOPIN & (1 << 25)) == 0) {
		if (position != 5) {
			position = 5;
		}
	}
	
	
	// update position
	if(game_state == 0){ // state run
		
		if(pacman_i == ghost_i && pacman_j == ghost_j) {
			firstGhostMove = 2;
			if(frightenedMode == -1) {
				board[pacman_i][pacman_j] = 0;
				board[spawnP_i][spawnP_j] = 6;
				board[spawnG_i][spawnG_j] = 10;
				lives--;
				drawLives();
				drawMap();
			} else {
				ghostAlive = 0;
				ghost_i = spawnG_i;
				ghost_j = spawnG_j;
				board[pacman_i][pacman_j] = 6;
				//enable_timer(2);
				flag_ghostDead = 1;
				point+=100;
				addPoint();
			}

		} else {
			switch(position){
				case 1:
					moveUp();
					break;
				case 2:
					moveRight();
					break;
				case 3:
					moveLeft();
					break;
				case 4:
					moveDown();
					break;
				default:
					break;
			}
			if(ghostSpeed >= 3) {
				moveGhost();
			} else if(ghostSpeed == 2) {
				if(ghostSpeedSkip == 1) {
					ghostSpeedSkip = 0;
					moveGhost();
				} else {
					ghostSpeedSkip++;
				}
			} else if(ghostSpeed == 1) {
				if(ghostSpeedSkip == 2) {
					ghostSpeedSkip = 0;
					moveGhost();
				} else {
					ghostSpeedSkip++;
				}
			}
		}
		
		
	}
	
	// Button 0 pressed
	if ((LPC_PINCON->PINSEL4 & (1 << 20)) == 0) {
    if ((LPC_GPIO2->FIOPIN & (1 << 10)) == 0) { // Button 0 pressed
        
				if(game_state == 0){
					game_state = 1; // pause the game
					drawGameStateBackground();
					drawMap();
					disable_timer(2);
					
					backgroundActive=0;
					playEatSound=0;
				} else if(game_state == 1) {
					game_state = 0; // run the game
					drawGameStateBackground();
					drawMap();
					enable_timer(2);
					
					backgroundActive=1;
				}
    }
	}
	
	// GESTIONE MUSICA
	if (isNotePlaying() /*&& game_state != 1*/) // Se non c'� una nota in corso
    {
        ++ticks;

        if (ticks == UPTICKS) // Controlla il timer
        {
            ticks = 0;

            if (playEatSound == 1) // Riproduci suono "mangiare"
            {
                playNote(eat_song[currentNoteEatSound++]);

                // Verifica se il suono "mangiare" � completo
                if (currentNoteEatSound == (sizeof(eat_song) / sizeof(eat_song[0])))
                {
                    currentNoteEatSound = 0;  // Resetta il suono
                    playEatSound = 0;         // Torna alla musica di sottofondo
                }
            }
            else if (backgroundActive == 1) // Riproduci musica di sottofondo
            {
                playNote(backgroundMusic[currentNoteBackground++]);

                // Controlla se la musica di sottofondo deve ripetersi
                if (currentNoteBackground == (sizeof(backgroundMusic) / sizeof(backgroundMusic[0])))
                {
                    currentNoteBackground = 0; // Ripeti la musica di sottofondo
                }
            }
        }
    }

		/*
    if (!backgroundActive && !playEatSound) // Disabilita l'interrupt se var sono a 0
    {
        disable_RIT();
    }*/

	// Clear interrupt flag
	LPC_RIT->RICTRL |= 0x1;
}


/******************************************************************************
**                            End Of File
******************************************************************************/
