/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include <string.h>
#include "LPC17xx.h"
#include "RIT.h"
#include "../timer/timer.h"
#include "../led/led.h"
//#include "../GLCD/GLCD.h"
#include "../ADC/adc.h"
//#include "../TouchPanel/TouchPanel.h"
#include "../music/music.h"

// Tones (speaker)
#define UPTICKS 1

NOTE eat_song[4] = {
	{0, 0x4C4B40},
	{500, 0x1C4B40},
	{700, 0x1C4B40},
	{1400, 0x4C4B40}
};

NOTE click = {1400, 0x0C4B40};

NOTE die_song[6] = {
	{e3, 0x989680},
	{f3, 0x4C4B40},
	{d3, 0x989680},
	{e3, 0x4C4B40},
	{c3, 0x989680},
	{d3, 0x4C4B40}
};

NOTE cuddle_song[9] = {
	{0, 0x4C4B40},
	{500, 0x4C4B40},
	{700, 0x4C4B40},
	{1000, 0x4C4B40},
	{1400, 0x4C4B40},
	{1000, 0x4C4B40},
	{700, 0x4C4B40},
	{500, 0x4C4B40},
	{700, 0x4C4B40}
};

NOTE song[] = 
{
	// 1
	{d3, time_semicroma},
	{d3, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 2
	{c3, time_semicroma},
	{c3, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 3
	{c3b, time_semicroma},
	{c3b, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 4
	{a2b, time_semicroma},
	{a2b, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 5
	
};

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
int play_tone = 1;
void RIT_IRQHandler (void)
{					
	static int j_down = 0, j_up = 0, j_left = 0, j_right = 0, j_sel = 0;
	static int down0 = 0, down1 = 0, down2 = 0;	
	
	static int ticks = 0;
	static int currentNote = 0;
	
	// Start ADC conversion (trimmer)
	ADC_start_conversion();
	
	
	// RIT Handler for INT0 button
	if((LPC_PINCON->PINSEL4 & (1 << 20)) == 0){
		down0++;
		if((LPC_GPIO2->FIOPIN & (1<<10)) == 0){
			switch(down0){
				case 1:
					// INT0 code
					break;
				default:
					break;
			}
		}
		else {	/* button released */
			down0=0;	
			NVIC_EnableIRQ(EINT0_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 20);     /* External interrupt 0 pin selection */
		}
	}
	
	// RIT Handler for KEY1 button
	if((LPC_PINCON->PINSEL4 & (1 << 22)) == 0){
		down1++;
		if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){
			switch(down1){
				case 1:
					// KEY 1 code
					break;
				default:
					break;
			}
		}
		else {	/* button released */
			down1=0;	
			NVIC_EnableIRQ(EINT1_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 0 pin selection */
		}
	}
	
	// RIT Handler for KEY2 button
	if((LPC_PINCON->PINSEL4 & (1 << 24)) == 0){
		down2++;
		if((LPC_GPIO2->FIOPIN & (1<<12)) == 0){			
			switch(down2){
				case 1:
					// KEY 2 code
					break;
				default:
					break;
			}
		}
		else {	/* button released */
			down2=0;
			NVIC_EnableIRQ(EINT2_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 24);     /* External interrupt 0 pin selection */
		}
	}
	
	/* Joytick LEFT pressed */
	if((LPC_GPIO1->FIOPIN & (1<<27)) == 0){	
		j_left++;
		switch(j_left){
			case 1:
				// code for left
				break;
			default:
				break;
		}
	}
	else{
			j_left=0;
	}
	
	/* Joytick RIGHT pressed */
	if((LPC_GPIO1->FIOPIN & (1<<28)) == 0){	
		j_right++;
		switch(j_right){
			case 1:
				// code for right
				break;
			default:
				break;
		}
	}
	else{
			j_right=0;
	}
	
	/* Joytick SELECT pressed */
	if((LPC_GPIO1->FIOPIN & (1<<25)) == 0){	
		j_sel++;
		switch(j_sel){
			case 1:
				// code for select
				break;
			default:
				break;
		}
	}
	else {
			j_sel=0;
	}
	
	/* Joytick DOWN pressed */
	if((LPC_GPIO1->FIOPIN & (1<<26)) == 0){	
		j_down++;
		switch(j_down){
			case 1:
				// code for select
				break;
			default:
				break;
		}
	}
	else {
			j_down=0;
	}
	
	/* Joytick UP pressed */
	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){	
		j_up++;
		switch(j_up){
			case 1:
				// code for select
				break;
			default:
				break;
		}
	}
	else {
			j_up=0;
	}
	
	// Pression on the Touch Panel (Touch Panel)
	/* 
	if(getDisplayPoint(&display, Read_Ads7846(), &matrix )){
		if(display.y > 80 && display.y < 280 && display.x > 20 && display.x < 200){
			// Click within the area x=(20, 200), y=(80, 280)
		}
	}
	*/
	
	
	// Play a tone (Speaker)
	/*
	if (play_tone == 1) {
		if(!isNotePlaying()) {
			++ticks;
			if(ticks == UPTICKS) {
				ticks = 0;
				playNote(eat_song[currentNote++]);
			}
		}
		
		if(currentNote == (sizeof(eat_song) / sizeof(eat_song[0]))) {
			play_tone = 0;
			currentNote = 0;
		}
	}*/
	
	if(!isNotePlaying())
	{
		++ticks;
		if(ticks == UPTICKS)
		{
			ticks = 0;
			playNote(song[currentNote++]);
		}
	}
	
	if(currentNote == (sizeof(song) / sizeof(song[0])))
	{
		disable_RIT();
	}
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
