/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_adc.c
** Last modified Date:  20184-12-30
** Last Version:        V1.00
** Descriptions:        functions to manage A/D interrupts
** Correlated files:    adc.h
**--------------------------------------------------------------------------------------------------------       
*********************************************************************************************************/

#include "LPC17xx.h"
#include "adc.h"

/*----------------------------------------------------------------------------
  A/D IRQ: Executed when A/D Conversion is ready (signal from ADC peripheral)
 *----------------------------------------------------------------------------*/

unsigned short AD_current;   
unsigned short AD_last = 0xFF;     /* Last converted value               */
uint8_t volume_last = 0;
uint8_t volume_current;

void ADC_IRQHandler(void) {
	static uint8_t first = 1;
	
  AD_current = ((LPC_ADC->ADGDR>>4) & 0xFFF);	/* Read Conversion Result             */
	if (first) {
		first = 0;
		volume_current = AD_current*7/0xFFF;
	}
	
	if(AD_current != AD_last){
		volume_current = AD_current*7/0xFFF;
		AD_last = AD_current;
		volume_last = volume_current;
  }	
}
