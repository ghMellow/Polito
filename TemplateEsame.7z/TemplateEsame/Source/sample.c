/*----------------------------------------------------------------------------
 * Name:    sample.c
 * Purpose: 
 *		to control led11 and led 10 through EINT buttons (similarly to project 03_)
 *		to control leds9 to led4 by the timer handler (1 second - circular cycling)
 * Note(s): this version supports the LANDTIGER Emulator
 * Author: 	Paolo BERNARDI - PoliTO - last modified 15/12/2020
 *----------------------------------------------------------------------------
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2017 Politecnico di Torino. All rights reserved.
 *----------------------------------------------------------------------------*/

                  
#include <stdio.h>
#include "LPC17xx.h"
//#include "GLCD/GLCD.h" 
#include "timer/timer.h"
#include "joystick/joystick.h"
#include "RIT/RIT.h"
#include "button_EXINT/button.h"
#include "led/led.h"
//#include "TouchPanel/TouchPanel.h"
//#include "adc/adc.h"
//#include "music/music.h"


/* Led external variables from funct_led */
extern unsigned char led_value;					/* defined in lib_led								*/
#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif

//extern float my_asm_function(float* a, float* b); // Assembly defined function

/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void) {
  	
  SystemInit();  												/* System Initialization (i.e., PLL)  */
  //LCD_Initialization();
	joystick_init();
	//TP_Init();
	//TouchPanel_Calibrate();
	//LCD_Clear(White);
	ADC_init();
	initSpeaker();
	LED_init();                           /* LED Initialization                 */
  BUTTON_init();	
	
	
	LPC_SC -> PCONP |= (1 << 22);  // TURN ON TIMER 2
	LPC_SC -> PCONP |= (1 << 23);  // TURN ON TIMER 3	


	//init_timer(2, 0, 2, 1, 0x017D7840); /* TIMER0 Initialization              */
																				/* K = T*Fr = [s]*[Hz] = [s]*[1/s]	  */
																				/* T = K / Fr = 0x017D7840 / 25MHz    */
																				/* T = K / Fr = 25000000 / 25MHz      */
																				/* T = 1s	(one second)   							*/							
	//enable_timer(2);
	/*
	init_timer(0, 0, 0, 0, 0); //MR0
	enable_timer(0);
	
	init_timer(1, 0, 0, 3, 0x1A7DAA4); //MR0
	enable_timer(1);
	
	init_timer(2, 0, 0, 1, 0x32DCD); //MR0  
	init_timer(2, 0, 1, 3, 0x43d11); //MR1
	enable_timer(2);
	
	init_timer(3, 0, 0, 1, 0x98968); //MR0
	init_timer(3, 0, 1, 3, 0x2625A0); //MR1
	enable_timer(3);
	*/
	
	//init_timer(2, 0, 1, 3, 0x00BEBC20); // MR1 reset&interupt. 
	/* 1s * 25MHz = 25*10^6 = 0x017D7840; to speedup emulation: 0x000CB735 or 0x00BEBC20 (1/2 s) */
	//enable_timer(2);

	init_RIT(0x004C4B40);									/* RIT Initialization 50 msec * 100 MHz = 0x004C4B40     */
	enable_RIT();
	
	LPC_SC->PCON |= 0x1;									/* power-down	mode										*/
	LPC_SC->PCON &= ~(0x2);						
	
	//__asm__("SVC 0xCA");
	
  while (1)	
  {
		__ASM("wfi");
  }

}

/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
