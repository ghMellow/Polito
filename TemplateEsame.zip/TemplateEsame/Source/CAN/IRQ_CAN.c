/*----------------------------------------------------------------------------
 * Name:    Can.c
 * Purpose: CAN interface for for LPC17xx with MCB1700
 * Note(s): see also http://www.port.de/engl/canprod/sv_req_form.html
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2009 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------*/

#include <LPC17xx.h>                  /* LPC17xx definitions */
#include "CAN.h"                      /* LPC17xx CAN adaption layer */
#include "../GLCD/GLCD.h"

extern uint8_t icr ; 										//icr and result must be global in order to work with both real and simulated landtiger.
extern uint32_t result;
extern CAN_msg       CAN_TxMsg;    /* CAN message for sending */
extern CAN_msg       CAN_RxMsg;    /* CAN message for receiving */                                

/*----------------------------------------------------------------------------
  CAN interrupt handler
 *----------------------------------------------------------------------------*/
 
static int var1 = 5, var2 = 6, var3 = 7;  // Variabili da inviare
int received_var1, received_var2, received_var3;  // Variabili ricevute
void CAN_IRQHandler(void) {

		icr = LPC_CAN1->ICR & 0xFF;  /* clear interrupts */

    if (icr & (1 << 0)) {  /* CAN Controller #1 message is received */
        CAN_rdMsg(1, &CAN_RxMsg);  /* Read the received message */
        
        /* Estrai i valori ricevuti dal messaggio */
        received_var1 = CAN_RxMsg.data[0];  // Supponiamo che i dati siano in CAN_RxMsg.data
        received_var2 = CAN_RxMsg.data[1];
        received_var3 = CAN_RxMsg.data[2];

        /* A questo punto, puoi fare qualcosa con le variabili ricevute */
        // Per esempio, stampare i valori o usarli per qualche calcolo
    }
    
    if (icr & (1 << 1)) {  /* CAN Controller #1 message is transmitted */
        // Nessuna azione specifica per la trasmissione in questo esempio
    }

    /* check CAN controller 2 */
    icr = LPC_CAN2->ICR & 0xFF;  /* clear interrupts */

    if (icr & (1 << 0)) {  /* CAN Controller #2 message is received */
        CAN_rdMsg(2, &CAN_RxMsg);  /* Read the received message */
        
        /* Estrai i valori ricevuti dal messaggio (Controller 2) */
        received_var1 = CAN_RxMsg.data[0];
        received_var2 = CAN_RxMsg.data[1];
        received_var3 = CAN_RxMsg.data[2];

        /* A questo punto, puoi fare qualcosa con le variabili ricevute */
        // Per esempio, aggiornare le variabili o fare un'elaborazione
    }
    
    if (icr & (1 << 1)) {  /* CAN Controller #2 message is transmitted */
        // Nessuna azione specifica per la trasmissione in questo esempio
    }
}

/* Funzione per inviare i messaggi dal CAN1 */
void CAN_sendMessage(void) {
    // Carica i dati nel messaggio da trasmettere
    CAN_TxMsg.data[0] = var1;
    CAN_TxMsg.data[1] = var2;
    CAN_TxMsg.data[2] = var3;

    // Scrivi il messaggio nel controller CAN1
    CAN_wrMsg(2, &CAN_TxMsg);
		CAN_wrMsg(1, &CAN_TxMsg);

    // A questo punto, il messaggio � stato inviato dal CAN1
}

/* Funzione di inizializzazione del CAN 
void CAN_Init(void) {
    // Inizializza il CAN1
    CAN_setup(1);
    CAN_start(1);
    CAN_waitReady(1);
    
    // Impostare il filtro per il CAN2, se necessario
    // CAN_wrFilter(2, id, filter_type);  // Sostituire 'id' e 'filter_type' come appropriato
    
    // Inizializza il CAN2
    CAN_setup(2);
    CAN_start(2);
    CAN_waitReady(2);
}*/

/* Funzione per l'invio del messaggio da CAN1 */
void CAN_sendDataFromCAN1(void) {
    // Invio dei dati da CAN1
    CAN_sendMessage();
}

/* Funzione di ricezione messaggi da CAN2 */
void CAN_receiveDataFromCAN2(void) {
    // La lettura dei messaggi dal CAN2 � gestita dentro l'ISR
}
