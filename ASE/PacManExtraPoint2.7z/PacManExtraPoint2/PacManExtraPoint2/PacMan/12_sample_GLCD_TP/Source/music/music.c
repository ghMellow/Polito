#include "LPC17xx.h"
#include "music.h"

#include "../timer/timer.h"

void playNote(NOTE note)
{
	if(note.freq != pause)
	{
	}
}

BOOL isNotePlaying(void)
{
	return ((LPC_TIM2->TCR != 0) || (LPC_TIM3->TCR != 0));
}

void initSpeaker(void){
	LPC_PINCON->PINSEL1 |= (1<<21);
	LPC_PINCON->PINSEL1 &= ~(1<<20);
	LPC_GPIO0->FIODIR |= (1<<26);
}
