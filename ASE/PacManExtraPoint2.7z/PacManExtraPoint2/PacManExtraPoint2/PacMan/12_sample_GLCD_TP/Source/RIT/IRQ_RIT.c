/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "GLCD.h"
#include <stdio.h>

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
#define HEIGTH 31
#define LENGTH 28
extern char board[HEIGTH][LENGTH];
extern int pacman_i; // y
extern int pacman_j; // x
extern int ghost_i; // y
extern int ghost_j; // x

int point = 0;
char scoreString[200];
int lives = 3;
int endGamePoint = 2700;
extern int game_state;


void drawLives(){
	switch(lives){
		case 0:
			GUI_Text(0, 280, (uint8_t *) " Lives: x_x			 ", White, Black);
			break;
		case 1:
			GUI_Text(0, 280, (uint8_t *) " Lives: (< 			 ", White, Black);
			break;
		case 2:
			GUI_Text(0, 280, (uint8_t *) " Lives: (< (< 	 ", White, Black);
			break;
		case 3:
			GUI_Text(0, 280, (uint8_t *) " Lives: (< (< (< ", White, Black);
			break;
		default:
			break;
		}
}
void addLive() {
	if(lives != 3 && point != 0 && point % 1000 == 0) {
		lives += 1;
		drawLives();
	}
}

volatile int countPills = 0;
int countPowerPills = 0;
void addPoint(){
	if(board[pacman_i][pacman_j] == 2) {
		countPills++;
		point += 10;
	} else if (board[pacman_i][pacman_j] == 3) {
		countPowerPills++;
		point += 50;
	}
	addLive();
	
	if(countPills + countPowerPills >= 240){
		game_state = 2;
		drawMap();
	}
	
	
	sprintf(scoreString, "      %d  ", point);
	GUI_Text(120, 20, (uint8_t *)scoreString, White, Black);
}

void teleport(int portal){
	if(portal == 1){
		pacman_i = 14;
		pacman_j = 26;
		board[pacman_i][pacman_j] = 6;
	} else {
		pacman_i = 14;
		pacman_j = 1;
		board[pacman_i][pacman_j]	= 6;
	}
}


int firstGhostMove = 2;
void moveGhost(){
	
	if(firstGhostMove != 0){
		firstGhostMove--;
		board[ghost_i][ghost_j] = 8;
		drawPoint(7);
		
		ghost_i--;
		board[ghost_i][ghost_j] = 7;
		drawPoint(7);
		
		// up,left,down,right
	} else if(ghost_i > pacman_i && (board[ghost_i-1][ghost_j] != 1 && board[ghost_i-1][ghost_j] != 8)) {
		board[ghost_i][ghost_j] = 0;
		drawPoint(7);
		
		ghost_i--;
		board[ghost_i][ghost_j] = 7;
		drawPoint(7);
		
	} else if(ghost_j > pacman_j && (board[ghost_i][ghost_j-1] != 1 && board[ghost_i][ghost_j-1] != 8)) {
		board[ghost_i][ghost_j] = 0;
		drawPoint(7);
		
		ghost_j--;
		board[ghost_i][ghost_j] = 7;
		drawPoint(7);		
	
	} else if(ghost_i < pacman_i && (board[ghost_i+1][ghost_j] != 1 && board[ghost_i+1][ghost_j] != 8)){
		board[ghost_i][ghost_j] = 0;
		drawPoint(7);
		
		ghost_i++;
		board[ghost_i][ghost_j] = 7;
		drawPoint(7);		
	
	} else if(ghost_j < pacman_j && (board[ghost_i][ghost_j+1] != 1 && board[ghost_i][ghost_j+1] != 8)) {
		board[ghost_i][ghost_j] = 0;
		drawPoint(7);
		
		ghost_j++;
		board[ghost_i][ghost_j] = 7;
		drawPoint(7);		
	}
}

void moveRight(){
    if(board[pacman_i][pacman_j + 1] == 5) {    
				board[pacman_i][pacman_j] = 0;
				drawPoint(6);
				
				teleport(0);
				drawPoint(6);
			
		} else if (board[pacman_i][pacman_j + 1] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
				drawPoint(6);
			
        pacman_j += 1;                           // Aggiorna la posizione del pacman
				addPoint();
        board[pacman_i][pacman_j] = 6;           // Imposta il pacman nella nuova posizione
				drawPoint(6);
    }
}

void moveLeft(){
    if(board[pacman_i][pacman_j - 1] == 4) {    
				board[pacman_i][pacman_j] = 0;
				drawPoint(6);
				teleport(1);
				drawPoint(6);
			
		} else if (board[pacman_i][pacman_j - 1] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
				drawPoint(6);
        pacman_j -= 1;                           // Aggiorna la posizione del pacman
				addPoint();
        board[pacman_i][pacman_j] = 6; 
				drawPoint(6);
		
		}
		
}

void moveDown(){
    if (board[pacman_i + 1][pacman_j] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
				drawPoint(6);
        pacman_i += 1;                           // Aggiorna la posizione del pacman
				addPoint();
        board[pacman_i][pacman_j] = 6;           // Imposta il pacman nella nuova posizione
				drawPoint(6);
    }
}

void moveUp(){
    if (board[pacman_i - 1][pacman_j] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
				drawPoint(6);
        pacman_i -= 1;                           // Aggiorna la posizione del pacman
				addPoint();
        board[pacman_i][pacman_j] = 6;           // Imposta il pacman nella nuova posizione
				drawPoint(6);
    }
}


volatile int bt=0;
static int position = 0;

void RIT_IRQHandler (void)
{					
	// Joystick UP
	if ((LPC_GPIO1->FIOPIN & (1 << 29)) == 0) {
		if (position != 1) { // Evita ripetizioni
			position = 1;
		}
	}

	// Joystick RIGHT
	if ((LPC_GPIO1->FIOPIN & (1 << 28)) == 0) {
		if (position != 2) {
			position = 2;
		}
	}

	// Joystick LEFT
	if ((LPC_GPIO1->FIOPIN & (1 << 27)) == 0) {
		if (position != 3) {
			position = 3;
		}
	}

	// Joystick DOWN
	if ((LPC_GPIO1->FIOPIN & (1 << 26)) == 0) {
		if (position != 4) {
			position = 4;
		}
	}

	// Joystick SELECT
	if ((LPC_GPIO1->FIOPIN & (1 << 25)) == 0) {
		if (position != 5) {
			position = 5;
		}
	}
	
	
	// update position
	if(game_state == 0){ // state run
		switch(position){
			case 1:
				moveUp();
				break;
			case 2:
				moveRight();
				break;
			case 3:
				moveLeft();
				break;
			case 4:
				moveDown();
				break;
			default:
				break;
		}
		moveGhost();
		//drawPoint(6);
		//drawMap();
	}
	
	// Button 0 pressed
	if ((LPC_PINCON->PINSEL4 & (1 << 20)) == 0) {
    if ((LPC_GPIO2->FIOPIN & (1 << 10)) == 0) { // Button 0 pressed
        
				if(game_state == 0){
					game_state = 1; // pause the game
					drawGameStateBackground();
					drawMap();
					disable_timer(1);
				} else if(game_state == 1) {
					game_state = 0; // run the game
					drawGameStateBackground();
					drawMap();
					enable_timer(1);
				}
    }
}

	// Clear interrupt flag
	LPC_RIT->RICTRL |= 0x1;
}


/******************************************************************************
**                            End Of File
******************************************************************************/
