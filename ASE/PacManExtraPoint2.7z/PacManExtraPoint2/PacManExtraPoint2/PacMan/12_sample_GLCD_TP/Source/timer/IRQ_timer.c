/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "timer.h"
#include "GLCD/GLCD.h"
#include <stdio.h>

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
extern int frightenedMode;
void TIMER0_IRQHandler (void)
{
	frightenedMode = -1;
	disable_timer(0);
	
  LPC_TIM0->IR |= 1;			/* clear interrupt flag */
  return;
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
int countDown = 60;

void drawCountDown(){
	char timerString[20];
	sprintf(timerString, "     %d   ", countDown);
	GUI_Text(0, 20, (uint8_t *)timerString, White, Black);
}

extern int powerPillsTime[6];
extern int game_state;
void TIMER1_IRQHandler (void)
{
	if(countDown != 0) {
		countDown -= 1;
		drawCountDown();
		
		if(countDown == 0){
			game_state = 3; // game over
			disable_timer(1);
			drawMap();
		}
		
		int i;
		for(i=0; i < 6; i++){
			if(powerPillsTime[i] == countDown){
				drawRandomPowerPills();
			}
		}
	}
	
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
extern int ghostAlive;
void TIMER2_IRQHandler (void)
{
	ghostAlive = 1;
	disable_timer(2);
	
  LPC_TIM2->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer3_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
extern int ghostSpeed;
void TIMER3_IRQHandler (void)
{
	ghostSpeed++;
	
  LPC_TIM3->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
