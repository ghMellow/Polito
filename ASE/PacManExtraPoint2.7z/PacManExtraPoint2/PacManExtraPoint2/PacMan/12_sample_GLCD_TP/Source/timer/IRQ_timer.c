/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "timer.h"
#include "GLCD/GLCD.h"
#include <stdio.h>

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
extern int frightenedMode;
int countDown_frightenedMode = 0, flag_frightenedMode = 0;
int countDown_ghostDead = 0, flag_ghostDead = 0;
int countDown_updateGhostSpeed = 0;


uint16_t SinTable[45] =                                       /* ���ұ�                       */
{
    410, 467, 523, 576, 627, 673, 714, 749, 778,
    799, 813, 819, 817, 807, 789, 764, 732, 694, 
    650, 602, 550, 495, 438, 381, 324, 270, 217,
    169, 125, 87 , 55 , 30 , 12 , 2  , 0  , 6  ,   
    20 , 41 , 70 , 105, 146, 193, 243, 297, 353
};
void TIMER0_IRQHandler (void)
{
	/*
	frightenedMode = -1;
	disable_timer(0);
	*/
	
	
	static int sineticks=0;
	/* DAC management */	
	static int currentValue; 
	currentValue = SinTable[sineticks];
	currentValue -= 410;
	currentValue /= 1;
	currentValue += 410;
	LPC_DAC->DACR = currentValue <<6;
	sineticks++;
	if(sineticks==45) sineticks=0;

	
  LPC_TIM0->IR |= 1;			/* clear interrupt flag */
  return;
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
int countDown = 60;

void drawCountDown(){
	char timerString[20];
	sprintf(timerString, "     %d   ", countDown);
	GUI_Text(0, 20, (uint8_t *)timerString, White, Black);
}

extern int powerPillsTime[6];
extern int game_state;
extern int ghostAlive;
extern int ghostSpeed;
void TIMER2_IRQHandler (void)
{
	if(countDown != 0) {
		
		//gestione velocit� fantasma
		countDown_updateGhostSpeed++;
		if(countDown_updateGhostSpeed == 15) {
			ghostSpeed++;
			countDown_updateGhostSpeed = 0;
		}
		
		//gestione fantasma morto
		if(flag_ghostDead == 1){
			countDown_ghostDead++;
			if(countDown_ghostDead == 3){
				ghostAlive = 1;
				
				countDown_ghostDead = 0;
				flag_ghostDead = 0;
			}
		}
		
		//gestione frightenedMode fantasma
		if(flag_frightenedMode == 1) {
			countDown_frightenedMode++;
			if(countDown_frightenedMode == 10) {
				frightenedMode = -1;
				
				countDown_frightenedMode = 0;
				flag_frightenedMode = 0;
			}
		}
	
		// gestione tempo di gioco
		countDown -= 1;
		drawCountDown();
		
		if(countDown == 0){
			game_state = 3; // game over
			disable_timer(2);
			drawMap();
		}
		
		int i;
		for(i=0; i < 6; i++){
			if(powerPillsTime[i] == countDown){
				drawRandomPowerPills();
			}
		}
	}
	
  LPC_TIM2->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

void TIMER1_IRQHandler (void)
{
	/*
	ghostAlive = 1;
	disable_timer(2);
	*/
	
	disable_timer(0);
	
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer3_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER3_IRQHandler (void)
{
	
  LPC_TIM3->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
