/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "GLCD.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
#define HEIGTH 31
#define LENGTH 28
extern char board[HEIGTH][LENGTH];
extern int pacman_i; // y
extern int pacman_j; // x

int next = 1;
int oldVal; 
int newVal;
	
void moveRight(){
    oldVal = board[pacman_i][pacman_j];
    if (board[pacman_i][pacman_j + 1] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
        pacman_j += 1;                           // Aggiorna la posizione del pacman
        board[pacman_i][pacman_j] = 6;           // Imposta il pacman nella nuova posizione
    }
    newVal = board[pacman_i][pacman_j-1];
}

volatile int bt=0;
int test;

void RIT_IRQHandler (void)
{					

	static int up=0;
	static int right=0;
	static int left=0;
	static int down=0;
	static int sel=0;	
	static int position=0;	
	
	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){	
		/* Joytick UP pressed */
		up++;
		switch(up){
			case 1:
				
				position = 0;
				break;
			default:
				break;
		}
	}
	else{
			up=0;
	}
	
	if((LPC_GPIO1->FIOPIN & (1<<28)) == 0){	
		/* Joytick RIGHT pressed */
		right++;
		switch(right){
			case 1:
				moveRight();
				drawMap();
				position = 0;
				break;
			default:
				break;
		}
	}
	else{
			right=0;
	}
	
	if((LPC_GPIO1->FIOPIN & (1<<27)) == 0){	
		/* Joytick LEFT pressed */
		left++;
		switch(left){
			case 1:
				//drawMap();
				position = 0;
				break;
			default:
				break;
		}
	}
	else{
			left=0;
	}
	
	if((LPC_GPIO1->FIOPIN & (1<<25)) == 0){	
		/* Joytick SEL pressed */
		sel++;
		switch(sel){
			case 1:
				//drawMap();
				position = 0;
				break;
			default:
				break;
		}
	}
	else{
			sel=0;
	}
	
	/* button management */
	if(bt>=1){ 
		if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){	/* KEY1 pressed */
			switch(bt){				
				case 2:				/* pay attention here: please see slides to understand value 2 */
				if( position == 7){
					
					position = 0;
				}
				else{
				}
					break;
				default:
					break;
			}
			bt++;
		}
		else {	/* button released */
			bt=0;			
			NVIC_EnableIRQ(EINT1_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 0 pin selection */
		}
	}
/*	else{
			if(down==1)
				down++;
	} */
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
