/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "GLCD.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
#define HEIGTH 31
#define LENGTH 28
extern char board[HEIGTH][LENGTH];
extern int pacman_i; // y
extern int pacman_j; // x

int next = 1;
int oldVal; 
int newVal;

void teleport(int portal){
	if(portal == 1){
		pacman_i = 14;
		pacman_j = 26;
		board[pacman_i][pacman_j] = 6;
	} else {
		pacman_i = 14;
		pacman_j = 1;
		board[pacman_i][pacman_j]	= 6;
	}
}
	
void moveRight(){
    if(board[pacman_i][pacman_j + 1] == 5) {    
				board[pacman_i][pacman_j] = 0;
				teleport(0);
			
		} else if (board[pacman_i][pacman_j + 1] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
        pacman_j += 1;                           // Aggiorna la posizione del pacman
        board[pacman_i][pacman_j] = 6;           // Imposta il pacman nella nuova posizione
    }
}

void moveLeft(){
    if(board[pacman_i][pacman_j - 1] == 4) {    
				board[pacman_i][pacman_j] = 0;
				teleport(1);
			
		} else if (board[pacman_i][pacman_j - 1] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
        pacman_j -= 1;                           // Aggiorna la posizione del pacman
        board[pacman_i][pacman_j] = 6; 
		
		}
		
}

void moveDown(){
    if (board[pacman_i + 1][pacman_j] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
        pacman_i += 1;                           // Aggiorna la posizione del pacman
        board[pacman_i][pacman_j] = 6;           // Imposta il pacman nella nuova posizione
    }
}

void moveUp(){
    if (board[pacman_i - 1][pacman_j] != 1) { 
        board[pacman_i][pacman_j] = 0;           // Libera la posizione corrente
        pacman_i -= 1;                           // Aggiorna la posizione del pacman
        board[pacman_i][pacman_j] = 6;           // Imposta il pacman nella nuova posizione
    }
}

volatile int bt=0;
static int position = 0;

void RIT_IRQHandler (void)
{					
		

	// Joystick UP
	if ((LPC_GPIO1->FIOPIN & (1 << 29)) == 0) {
		if (position != 1) { // Evita ripetizioni
			position = 1;
		}
	}

	// Joystick RIGHT
	if ((LPC_GPIO1->FIOPIN & (1 << 28)) == 0) {
		if (position != 2) {
			position = 2;
		}
	}

	// Joystick LEFT
	if ((LPC_GPIO1->FIOPIN & (1 << 27)) == 0) {
		if (position != 3) {
			position = 3;
		}
	}

	// Joystick DOWN
	if ((LPC_GPIO1->FIOPIN & (1 << 26)) == 0) {
		if (position != 4) {
			position = 4;
		}
	}

	// Joystick SELECT
	if ((LPC_GPIO1->FIOPIN & (1 << 25)) == 0) {
		if (position != 5) {
			position = 5;
		}
	}
	
	
	// update position
	switch(position){
		case 1:
			moveUp();
			break;
		case 2:
			moveRight();
			break;
		case 3:
			moveLeft();
			break;
		case 4:
			moveDown();
			break;
		default:
			break;
	}
	drawMap();

	// Clear interrupt flag
	LPC_RIT->RICTRL |= 0x1;
}


/******************************************************************************
**                            End Of File
******************************************************************************/
