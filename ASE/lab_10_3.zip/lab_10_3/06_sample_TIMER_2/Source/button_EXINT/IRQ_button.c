#include "button.h"
#include "LPC17xx.h"


#include "../led/led.h"
#include "../timer/timer.h"

extern int down_0;
extern int down_1;
extern int down_2;

void bubblesort(int n) {
	float sum;
int i,k;
int temp;
for(i = 0; i<n-1; i++) {
	sum+=camp[i];
 for(k = 0; k<n-1-i; k++) {
         if(camp[k] > camp[k+1]) {
          temp = camp[k];
          camp[k] = camp[k+1];
          camp[k+1] = temp;
         }
 }
}
sum+=camp[n-1];
sum=sum/n;
}

void clean_vector(int n){
	int i =0;
	for(i=0; i<n; i++){
		camp[i]=0xCAFECAFE;
	}
}

void EINT0_IRQHandler (void)	  	/* INT0														 */
{
	
	LPC_SC->EXTINT &= (1 << 0);     /* clear pending interrupt         */
}


void EINT1_IRQHandler (void)	  	/* KEY1														 */
{
	down_1 = 1;
	NVIC_DisableIRQ(EINT1_IRQn);		/* disable Button interrupts			 */
	LPC_PINCON->PINSEL4    &= ~(1 << 22);     /* GPIO pin selection */
	
	bubblesort(7000);
	clean_vector(7000);
	
	LPC_SC->EXTINT &= (1 << 1);     /* clear pending interrupt         */
}

void EINT2_IRQHandler (void)	  	/* KEY2														 */
{
	LPC_SC->EXTINT &= (1 << 2);     /* clear pending interrupt         */  
	enable_timer(0);  
}


