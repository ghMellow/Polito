/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include <string.h>
#include "lpc17xx.h"
#include "timer.h"
#include "../RIT/RIT.h"
#include "../led/led.h"
//#include "../GLCD/GLCD.h"
//#include "../music/music.h"

/* Sinusoid (speaker)
uint16_t SinTable[45] =                                       
{
    410, 467, 523, 576, 627, 673, 714, 749, 778,
    799, 813, 819, 817, 807, 789, 764, 732, 694, 
    650, 602, 550, 495, 438, 381, 324, 270, 217,
    169, 125, 87 , 55 , 30 , 12 , 2  , 0  , 6  ,   
    20 , 41 , 70 , 105, 146, 193, 243, 297, 353
};
*/

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

void TIMER0_IRQHandler (void)
{	
	
  LPC_TIM0->IR = 1;			/* clear interrupt flag */
  return;
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER1_IRQHandler (void)
{
	
  LPC_TIM1->IR |= 1;			/* clear interrupt flag */
  return;
}


void TIMER2_IRQHandler (void)
{
	// Play sounds (speaker)
	/*
	static int sineticks=0;
	// DAC management
	static int currentValue; 
	currentValue = SinTable[sineticks];
	currentValue -= 410;
	currentValue /= 1;
	currentValue += 410;
	LPC_DAC->DACR = currentValue << volume_current;
	sineticks++;
	if(sineticks==45) sineticks=0;
	*/
	
	// Double MR
	/*
	static int led_on = 0;
	
	if(LPC_TIM2->IR == 1){		// MR0 interrupt 
		if(led_on){
			LED_Off(3);
			led_on = 0;
		}
		LPC_TIM2->IR |= 1;			// clear MR0 interrupt flag 
	} else if(LPC_TIM2->IR == 2){		// MR1 interrupt 
		if(!led_on){
			LED_On(3);
			led_on = 1;
		}
		LPC_TIM2->IR |= 2;			// clear MR1 interrupt flag 
	}
	*/
	
	LPC_TIM2->IR |= 1;			// clear MR0 interrupt flag
  return;
}

void TIMER3_IRQHandler (void)
{
	// End tone (speaker)
	/*
	disable_timer(2);
	disable_timer(3);
	*/
	
	LPC_TIM3->IR |= 1;			/* clear MR0 interrupt flag */	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
