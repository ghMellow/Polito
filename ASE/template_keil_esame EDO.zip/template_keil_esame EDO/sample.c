/****************************************Copyright (c)****************************************************
**                                      
**                                 http://www.powermcu.com
**
**--------------File Info---------------------------------------------------------------------------------
** File name:               main.c
** Descriptions:            The GLCD application function
**
**--------------------------------------------------------------------------------------------------------
** Created by:              AVRman
** Created date:            2010-11-7
** Version:                 v1.0
** Descriptions:            The original version
**
**--------------------------------------------------------------------------------------------------------
** Modified by:             Paolo Bernardi
** Modified date:           03/01/2020
** Version:                 v2.0
** Descriptions:            basic program for LCD and Touch Panel teaching
**
*********************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "LPC17xx.h"
//#include "GLCD/GLCD.h" 
#include "timer/timer.h"
//#include "joystick/joystick.h"
#include "RIT/RIT.h"
#include "button_EXINT/button.h"
#include "led/led.h"
//#include "TouchPanel/TouchPanel.h"
//#include "adc/adc.h"
//#include "music/music.h"

#define SIMULATOR 1

#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif

//extern float my_asm_function(float* a, float* b); // Assembly defined function

int main(void)
{
  SystemInit();  												/* System Initialization (i.e., PLL)  */
  //LCD_Initialization();
	//joystick_init();
	//TP_Init();
	//TouchPanel_Calibrate();
	//LCD_Clear(White);
	//ADC_init();
	//initSpeaker();
	//LED_init();                           /* LED Initialization                 */
  //BUTTON_init();	
	
	init_timer(0, 0x017D7840); 						/* 1s * 25MHz = 25*10^6 = 0x017D7840; to speedup emulation: 0x000CB735 or 0x00BEBC20 (1/2 s) */
	enable_timer(0);

	init_RIT(0x004C4B40);									/* RIT Initialization 50 msec * 100 MHz = 0x004C4B40     */
	enable_RIT();
	
	LPC_SC->PCON |= 0x1;									/* power-down	mode										*/
	LPC_SC->PCON &= ~(0x2);						
	
	//__asm__("SVC 0xCA");
	
  while (1)	
  {
		__ASM("wfi");
  }
}

/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
