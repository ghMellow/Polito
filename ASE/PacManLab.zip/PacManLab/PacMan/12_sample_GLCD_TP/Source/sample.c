/****************************************Copyright (c)****************************************************
**                                      
**                                 http://www.powermcu.com
**
**--------------File Info---------------------------------------------------------------------------------
** File name:               main.c
** Descriptions:            The GLCD application function
**
**--------------------------------------------------------------------------------------------------------
** Created by:              AVRman
** Created date:            2010-11-7
** Version:                 v1.0
** Descriptions:            The original version
**
**--------------------------------------------------------------------------------------------------------
** Modified by:             Paolo Bernardi
** Modified date:           03/01/2020
** Version:                 v2.0
** Descriptions:            basic program for LCD and Touch Panel teaching
**
*********************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "LPC17xx.h"
#include "GLCD/GLCD.h" 
#include "TouchPanel/TouchPanel.h"
#include "timer/timer.h"
#include <math.h>
#include <stdio.h>


#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif

#define M_PI 3.14159265358979323846
#define HEIGTH 31
#define LENGTH 28
#define SCALE 7
#define PADD_X 20
#define PADD_Y 40
#define INIT_TIMER 0xC8

/*
 0: Vuoto
 1: Muro
 2: Point
 3: Special Point
 4: TP-Left
 5: TP-Right
 6: Pac-man
*/
volatile char board[HEIGTH][LENGTH] = {
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
        {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
				{4, 0, 2, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 5},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1}, 
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 6, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 1},
        {1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1},
        {1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1},
        {1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1},
        {1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1},
        {1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1},
        {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
    };

//volatile int powerPillsTime = 0;
volatile int powerPillsTime[6];  // Vettore di 6 elementi
volatile int pacman_i = 0;
volatile int pacman_j = 0;
		
int countPoint;
int game_state = 1; // 0 run, 1 pause, 2 win, 3 lose
char infoGameState[100];

		
void draw_null(int x, int y, int padd_x, int padd_y){
	int i=0;
	for(i=0; i < SCALE; i++){
		LCD_DrawLine(x + i + padd_x, y + padd_y, x + i + padd_x, y + SCALE + padd_y, Black);
	}
}
		
void draw_wall(int x, int y, int padd_x, int padd_y){
	int i=0;
	for(i=0; i < SCALE; i++){
		//LCD_DrawLine(x + i + padd_x, y + padd_y, x + i + padd_x, y + SCALE + padd_y, Blue);
		LCD_SetPoint(x + i + padd_x, 4+y + padd_y, Blue);
	}
}

void draw_point(int x, int y, int padd_x, int padd_y){
	LCD_SetPoint(3+x + padd_x, 4+y + padd_y, White);	
}

void draw_pills(int x, int y, int padd_x, int padd_y){
	int i=0;
	for(i=2; i < SCALE-2; i++){
		LCD_DrawLine(x + i + padd_x, y + 2 + padd_y, x + i + padd_x, y + SCALE-2 + padd_y, White);
	}
}

void DrawCircle(int centerX, int centerY, int radius, int color, int angle_start, int angle_end, int padd_x, int padd_y) {
//void DrawCircle(int centerX, int centerY, int radius, int color, char mouthDirection){
    // Convert angles from degrees to radians
    float angle_start_rad = angle_start * M_PI / 180.0;
    float angle_end_rad = angle_end * M_PI / 180.0;
		float angle;
 
    // Loop through every angle in the range to draw lines from center to perimeter
    for (angle = angle_start_rad; angle <= angle_end_rad; angle += 0.1) { // increment angle in small steps
        // Calculate the points on the circle's perimeter
        int x = padd_x + centerX + (int)(radius * cos(angle));
        int y = padd_y + centerY + (int)(radius * sin(angle));
				int i = 0;
 
        // Fill the area by drawing vertical lines from center to perimeter
        for (i = 0; i <= radius; i++) {
            int fillX = padd_x + centerX + (int)(i * cos(angle));
            int fillY = padd_y + centerY + (int)(i * sin(angle));
 
            // Set the pixel at (fillX, fillY) with the specified color
            LCD_SetPoint(fillX, fillY, color);
        }
    }
}

void drawGameStateBackground() {
	int i=0;
	int blocco;
	for(blocco = 1; blocco < ((SCALE*2)+3); blocco ++) {
		for(i=0; i < SCALE+1; i++){
			LCD_DrawLine((blocco*8)+50+i, 133, (blocco*8)+50+i, 160, Black);
		}
	}
}

void drawMap(){
	if(game_state == 0) {
		int i = 0, j = 0;
		for(i = 0; i < HEIGTH; i++) {
			for(j = 0; j < LENGTH; j++) {
				
				switch(board[i][j]){
					
					case 0:
						draw_null(j*SCALE, i*SCALE, PADD_X, PADD_Y);
						break;
					case 1:
						draw_wall(j*SCALE, i*SCALE, PADD_X, PADD_Y);
						break;
					case 2:
						draw_point(j*SCALE, i*SCALE, PADD_X, PADD_Y);
						break;
					case 3:
						//DrawCircle(j*SCALE, i*SCALE, 3, White, 0, 360, PADD_X+4, PADD_Y+4);
						draw_pills(j*SCALE, i*SCALE, PADD_X, PADD_Y);
						break;
					case 6:
						DrawCircle(j*SCALE, i*SCALE, 3, Yellow, 0, 360, PADD_X+4, PADD_Y+4);
						pacman_j = j;
						pacman_i = i;
						//draw_wall(j*SCALE, i*SCALE, PADD_X, PADD_Y);
						break;
				}
			}	
		}
		} else if(game_state == 1) {
			sprintf(infoGameState, "  > PAUSE <  ");
			GUI_Text(70, 140, (uint8_t *) infoGameState, White, Black);
		} else if(game_state == 2) {
			drawGameStateBackground();
			sprintf(infoGameState, "  > VICTORY <  ");
			GUI_Text(60, 140, (uint8_t *) infoGameState, White, Black);
		} else if(game_state == 3) {
			drawGameStateBackground();
			sprintf(infoGameState, "  > GAME OVER <  ");
			GUI_Text(55, 140, (uint8_t *) infoGameState, White, Black);
		}
}


unsigned int generateRandomNumber() {
    ADC_start_conversion();  // Start the ADC conversion

    // Wait for the ADC conversion to complete
    while (!(LPC_ADC->ADGDR & (1 << 31))) {
        // Wait for the ADC interrupt flag (done bit)
    }

    // Read the conversion result after it's complete
    return ((LPC_ADC->ADGDR >> 4) & 0xFFF);
}


void setRandomPositions() {
		//srand(LPC_TIM0->TC);
    srand(generateRandomNumber());
		
		int i;
		for (i = 0; i < 6; i++) {
        powerPillsTime[i] = rand() % 50;
    }
		
		// da cambiare seguendo la var tempo che se equivale a uno dei powerPillsTime[i] allora usa codice sotto per generare nella mappa
		int attempt = 0;
    while (attempt < 6) {
        int row = rand() % HEIGTH;  // Riga casuale
        int col = rand() % LENGTH;  // Colonna casuale
        if (board[row][col] == 2) {
            board[row][col] = 3;
						attempt++;
        }
    }
}

int countTwosInMatrix() {
    int count = 0;
		int i, j;
    for (i = 0; i < HEIGTH; i++) {
        for (j = 0; j < LENGTH; j++) {
            if (board[i][j] == 2) {
                count++;
            }
        }
    }
    return count;
}


int main(void)
{
  SystemInit();  												/* System Initialization (i.e., PLL)  */
	ADC_init();														/* Potenziometro Initialization              */
	BUTTON_init();												/* BUTTON Initialization              */
	joystick_init();											/* Joystick Initialization            */
	init_RIT(0x004C4B40);									/* RIT Initialization 50 msec       	*/
	enable_RIT();	
	
  LCD_Initialization();
  TP_Init();
	//TouchPanel_Calibrate();
	LCD_Clear(Black);
	
	char infoTop[100];
	sprintf(infoTop, " > Time left:     > Score:    ");
	GUI_Text(0, 0, (uint8_t *) infoTop, White, Black); // y=20

	drawLives();
	setRandomPositions();
	drawMap();
	
	addPoint();
	drawCountDown();
	init_timer(1, 0, 0, 3, 0x17D7840);
	//enable_timer(1);
	
	countPoint = countTwosInMatrix();

	
	LPC_SC->PCON |= 0x1;									/* power-down	mode										*/
	LPC_SC->PCON &= ~(0x2);	
	
  while (1)
  {
		__ASM("wfi");
  }
}

/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
