/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "../led/led.h"
#include "../timer/timer.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
// beat 1/4 = 1.65/4 seconds
#define RIT_SEMIMINIMA 8
#define RIT_MINIMA 16
#define RIT_INTERA 32

#define UPTICKS 1


//SHORTENING UNDERTALE: TOO MANY REPETITIONS
/*
NOTE song[] = 
{
	// 1
	{d3, time_semicroma},
	{d3, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 2
	{c3, time_semicroma},
	{c3, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 3
	{c3b, time_semicroma},
	{c3b, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 4
	{a2b, time_semicroma},
	{a2b, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 5
	
};*/
// Variabili globali
volatile int backgroundActive = 1;  // 1: musica di sottofondo attiva, 0: interrotta
volatile int playEatSound = 0;      // 1: riproduci suono "mangiare", 0: continua musica di sottofondo

// Note per i suoni
/*
NOTE backgroundMusic[8] = {
    {0, 0x3C4B40}, {400, 0x4C4B40}, {800, 0x5C4B40}, {1200, 0x4C4B40},
    {1600, 0x3C4B40}, {2000, 0x2C4B40}, {2400, 0x3C4B40}, {2800, 0x4C4B40}
};*/


NOTE eat_song[4] = {
	//{0, 0x4C4B40},
	{500, 0x1C4B40},
	{700, 0x1C4B40},
	//{1400, 0x4C4B40}
};

NOTE click = {1400, 0x0C4B40};


NOTE backgroundMusic[6] = {
	{e3, 0x989680},
	{f3, 0x4C4B40},
	{d3, 0x989680},
	{e3, 0x4C4B40},
	{c3, 0x989680},
	{d3, 0x4C4B40}
};

// Variabili per tenere traccia dello stato delle note
static int currentNoteBackground = 0;
static int currentNoteEatSound = 0;
static int ticks = 0;

void RIT_IRQHandler (void)
{
    if (!isNotePlaying()) // Se non c'� una nota in corso
    {
        ++ticks;

        if (ticks == UPTICKS) // Controlla il timer
        {
            ticks = 0;

            if (playEatSound) // Riproduci suono "mangiare"
            {
                playNote(eat_song[currentNoteEatSound++]);

                // Verifica se il suono "mangiare" � completo
                if (currentNoteEatSound == (sizeof(eat_song) / sizeof(eat_song[0])))
                {
                    currentNoteEatSound = 0;  // Resetta il suono
                    playEatSound = 0;         // Torna alla musica di sottofondo
                }
            }
            else if (backgroundActive) // Riproduci musica di sottofondo
            {
                playNote(backgroundMusic[currentNoteBackground++]);

                // Controlla se la musica di sottofondo deve ripetersi
                if (currentNoteBackground == (sizeof(backgroundMusic) / sizeof(backgroundMusic[0])))
                {
                    currentNoteBackground = 0; // Ripeti la musica di sottofondo
                }
            }
        }
    }

    if (!backgroundActive && !playEatSound) // Disabilita l'interrupt se var sono a 0
    {
        disable_RIT();
    }

    LPC_RIT->RICTRL |= 0x1; // Pulisci il flag di interrupt
}

/******************************************************************************
**                            End Of File
******************************************************************************/
